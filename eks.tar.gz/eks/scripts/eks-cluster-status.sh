#!/bin/bash
echo "Creating EKS Cluster"
        aws eks create-cluster \
        --region ap-southeast-1 \
        --name giteks \
        --kubernetes-version 1.17 \
        --role-arn arn:aws:iam::034342959684:role/eksClusterRole \
        --resources-vpc-config subnetIds=subnet-09b92de6e611d1e71,subnet-0c88c66923134ad92,subnet-0bb26d35701e89853,securityGroupIds=sg-0905c3788b49e1c6e


        STATUS=$(aws eks --region ap-southeast-1 describe-cluster --name giteks --query cluster.status)
        while [ "$STATUS" != '"ACTIVE"' ]; do
        STATUS=$(aws eks --region ap-southeast-1 describe-cluster --name giteks --query cluster.status)
           echo "Creating EKS Cluster": status: $STATUS
           sleep 60
        done
        echo "EKS Cluster Created"
